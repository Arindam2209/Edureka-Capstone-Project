package com.tcs.bankAccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
